#include <atmel_start.h>
#include <string.h>
#include <stdio.h>

#include "driver_examples.h"

#define MAX_DBG_MSG_LEN     128
#define STACK_SIZE          500

struct io_descriptor *dbg_io;
char debug_buff[MAX_DBG_MSG_LEN];

void uart_for_dbg_init(void)
{
    //extern struct io_descriptor *dbg_io;
    usart_sync_get_io_descriptor(&USART_0, &dbg_io);
    usart_sync_enable(&USART_0);
}

void debugMsg(struct io_descriptor* const io_descr, const char* msg, uint8_t len) //
{
    io_write(io_descr, (uint8_t *)msg, len);
}
void periodicPrintTask(void * pvParameters)
{
    for(;;)
    {
        uint32_t number_to_print = (uint32_t)pvParameters;
        uint8_t len = snprintf(debug_buff, MAX_DBG_MSG_LEN, "Test message: %lu\r\n", number_to_print);
        //debugMsg(dbg_io, debug_buff, len);
        *(uint32_t*)pvParameters = number_to_print + 1;
        //Toggle PC18 pin (yellow LED) here
        gpio_toggle_pin_level(GPIO(GPIO_PORTC, 18));
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}


int main(void)
{
    uint32_t number = 10;

    uint8_t len = snprintf(debug_buff, MAX_DBG_MSG_LEN, "Test message: %lu\r\n", number);
    //debugMsg(dbg_io, debug_buff, len);

    /* Initializes MCU, drivers and middleware */
    atmel_start_init();
    uart_for_dbg_init();

    BaseType_t xReturned = pdPASS;
    TaskHandle_t xHandle = NULL;

    /* Create the task, storing the handle. */
    xReturned = xTaskCreate(periodicPrintTask, "periodicPrintTask", STACK_SIZE, ( void * ) number, tskIDLE_PRIORITY+3, &xHandle);

    if(pdPASS != xReturned)
    {
        /* The task was not created. Use the task's handle to delete the task. */
        vTaskDelete(xHandle);
        ASSERT(0);
    }

    vTaskStartScheduler();

	/* Replace with your application code */
	while (1) {
        uint8_t len = snprintf(debug_buff, MAX_DBG_MSG_LEN, "Test message: %lu\r\n", number);
        debugMsg(dbg_io, debug_buff, len);
        ++number;
        delay_ms(1000);
	}
}
